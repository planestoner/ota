def custo():
    print("hello world")
    return "hello world"